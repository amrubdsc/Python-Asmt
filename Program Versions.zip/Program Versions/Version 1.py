'''The function of this program is to create a shopping list where you can add,
remove and view the shopping list, to help the user remember the groceries that
they need.'''

# items in store (these are high demand)
store_items = {
    "apple": 1.70,
    "banana": 1.40,
    "bread": 2.80
}

# shopping cart starts empty
cart = {}

# creating and declaring the functions
def show_cart():
    if not cart:
        print("Your cart is currently empty.")
    else:
        print("\nYour Cart:")
        for item, qty in cart.items():
            print(f"- {item.title()} x{qty}")

def show_store_items():
    print("\nAvailable Items:")
    for item, price in store_items.items():
        print(f"- {item.title()} (${price:.2f})")

def add_to_cart():
    while True:
        item = input("Enter item to buy (or 'n' to stop): ").lower()
        if item == 'n':
            break
        if item not in store_items:
            print("Item not found in store.")
            continue
        try:
            qty = int(input("Enter quantity: "))
            if qty <= 0:
                print("Invalid quantity. Item quantity cannot be negative.")
                continue
        except ValueError:
            print("Invalid input. Please enter a valid number.")
            continue
        cart[item] = cart.get(item, 0) + qty
        print(f"Added {qty} {item}(s) to cart.")
        more = input("Buy more items? (y/n): ").lower()
        if more != 'y':
            break


'''.lower() accepts user entries like "YeS or yES",
etc, allowing the code to still understand and convert entries'''
   

def show_summary():
    if not cart:
        print("Your cart is empty. Goodbye!")
        return
    print("\nFinal Cart Summary:")
    total = 0
    for item, qty in cart.items():
        item_total = store_items[item] * qty
        total += item_total
        print(f"- {item.title()} x{qty}: ${item_total:.2f}")#2f rounds to 2dp
    print(f"Total: ${total:.2f}")

# this is the loop of the program
while True:
    start = input("Start shopping? (y/n): ").lower()
    if start != 'y':
        print("Goodbye!")
        break

    show_cart()
    show_store_items()

    buy = input("\nDo you want to buy something? (y/n): ").lower()
    if buy == 'y':
        add_to_cart()
        show_summary()
    else:
        print("Thank you for visiting!")
        break

    restart = input("\nContinue shopping? (y/n): ").lower()
    if restart != 'y':
        print("Thank you for shopping. Goodbye!")
        break
