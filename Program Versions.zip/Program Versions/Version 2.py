'''The function of this program is to create a shopping list where you can add,
remove and view the shopping list, to help the user remember the groceries that
they need, but with an enhanced user interface that takes control of EasyGUI.
I also added new store_items to allow the user to have a wider variety of
store items to add.'''
from easygui import * # this imports all the libraries for EasyGui

# items in store (these are high demand)
store_items = {
    "apple": 1.70,
    "banana": 1.40,
    "bread": 2.80,  #I added new items to give the user better and more options.
    "chips": 3.10,
    "chocolate": 2.50,
    "biscuits": 3.20,
    "pancakes": 4.20,
    "hashbrowns": 6.50
}

# shopping cart starts empty
cart = {}

# creating and declaring the functions
def show_cart():
    if not cart:
        msgbox("Your cart is currently empty.")
    else:
        msgbox("\nYour Cart:")# using \n allows to create a new line in the code.
        for item, qty in cart.items():
            msgbox(f"- {item.title()} x{qty}")# the x is the amount of quanitity

#i used items_text to create a placeholder value.
#this placeholder value contains all the store items.
#by eventually calling it at msgbox(items_text),
#it allows to display all the items at once, instead of constant popups
def show_store_items():
    items_text = "Available Items:\n"#new line to display items
    for item, price in store_items.items():
        items_text += f"- {item.title()} (${price:.2f})\n"
    msgbox(items_text)
    
def add_to_cart():
    while True:
        item = enterbox("Enter item to buy (or 'n' to stop): ").lower()
        if item == 'n':
            break
        if item not in store_items:
            msgbox("Item not found in store.")
            continue
        qty = enterbox("Enter quantity: ")
        if not qty.isdigit() or int(qty) <= 0:
            msgbox("Invalid quantity. Please enter a positive number.")
            continue
        qty = int(qty)
        cart[item] = cart.get(item, 0) + qty
#decided to add current total here, rounding price to 2 dp like i did everywhere
        price = store_items[item] #defining the variable price to show in msgbox
        msgbox(f"Added {qty} {item}(s) to cart. (${price * qty:.2f})")
#using price * qty shows the cost of the item based on the quantity user wants
        more = enterbox("Buy more items? (y/n): ").lower()
        if more != 'y':
            break

def show_summary():#displaying the total of the shopping cart.
    if not cart:
        msgbox("Your cart is empty. Goodbye!")
        return
    summary_text = "Final Cart Summary:\n"
    total = 0
    for item, qty in cart.items():
        item_total = store_items[item] * qty
        total += item_total
        summary_text += f"- {item.title()} x{qty}: ${item_total:.2f}\n"
    summary_text += f"\nTotal: ${total:.2f}"
    msgbox(summary_text)


# this is the loop of the program
while True:
    start = enterbox("Start shopping? (y/n): ").lower()
    if start != 'y':
        msgbox("Goodbye!")
        break

    show_cart()
    show_store_items()

    buy = enterbox("\nDo you want to buy something? (y/n): ").lower()
    if buy == 'y':
        add_to_cart()
        show_summary()
    else:
        msgbox("Thank you for visiting!")
        break

    restart = enterbox("\nContinue shopping? (y/n): ").lower()
    if restart != 'y':
        msgbox("Thank you for shopping. Goodbye!")
        break
