'''The function of this program is to create a shopping list where you can add,
remove and view the shopping list, to help the user remember the groceries that
they need, but with an enhanced user interface that takes control of EasyGUI.
I also added new store_items to allow the user to have a wider variety of
store items to add compared to version 1. In this version 3 I will introduce
the use of matplotlib graph and plotting it from a txt file.
Taking it a step further, I am also giving users the option to see the graph
or not.
I adressed that users might make typos, to account for this, i replaced all
enterboxes with yes and no boxes (ynbox), allowing simple guidance and making
a better and more user friendly experience.'''
from easygui import * # this imports all the libraries for EasyGui

import matplotlib.pyplot as plt#importing necessary libraries to plot graph
import pandas as pd

#my file to store transaction history
transaction = "transactions.txt"
#items in store (these are high demand)
store_items = {
    "apple": 1.70,
    "banana": 1.40,
    "bread": 2.80,  #I added new items to give the user better and more options.
    "chips": 3.10,
    "chocolate": 2.50,
    "biscuits": 3.20,
    "pancakes": 4.20,
    "hashbrowns": 6.50
}

# shopping cart starts empty
cart = {}

# creating and declaring the functions
def show_cart():
    if not cart:
        msgbox("Your cart is currently empty.")
    else:
        msgbox("\nYour Cart:")# using \n allows to create a new line in the code.
        for item, qty in cart.items():
            msgbox(f"- {item.title()} x{qty}")# the x is the amount of quanitity

#i used items_text to create a placeholder value.
#this placeholder value contains all the store items.
#by eventually calling it at msgbox(items_text),
#it allows to display all the items at once, instead of constant popups
def show_store_items():
    items_text = "Available Items:\n"#new line to display items
    for item, price in store_items.items():
        items_text += f"- {item.title()} (${price:.2f})\n"
    msgbox(items_text)
    
def add_to_cart():
    while True:
        #creates button choices with prices displayed
        choices = [f"{item.title()} (${price:.2f})" for item, price in store_items.items()]
        choices.append("Cancel")
        
        selected = buttonbox("Select item to buy:", choices=choices)
        if selected == "Cancel" or selected is None:
            break#error catching avoids the code from crashing
            
        #this takes the item name from user's button selection
        item = selected.split(" (")[0].lower()
        
        if item not in store_items:
            msgbox("Item not found in store.")
            continue
            
        qty = enterbox(f"Enter quantity for {item.title()}: ")
        if qty is None:
            break
        if not qty.isdigit() or int(qty) <= 0:
            msgbox("Invalid quantity. Please enter a positive number.")
            continue
            
        qty = int(qty)
        cart[item] = cart.get(item, 0) + qty
        price = store_items[item]
        msgbox(f"Added {qty} {item}(s) to cart. (${price * qty:.2f})")
        
        more = ynbox("Buy more items?")#yes and no button box
        if not more:
            break


def get_valid_date():#Functions gets the date of the transaction from the user
    while True:
        date_str = enterbox("Enter the transaction date for example, 15/06/2025):")
        if date_str and date_str.strip() != "":
            #.strip() removes spaces from the start and end of users input
            return date_str.strip()
        else: #tells user that they have to enter a value
            msgbox("You must enter a date.")


def show_summary():#displaying the total of the shopping cart.
    if not cart:
        msgbox("Your cart is empty. Goodbye!")
        return    
    summary_text = "Final Cart Summary:\n"
    total = 0
    for item, qty in cart.items():
        item_total = store_items[item] * qty
        total += item_total
        summary_text += f"- {item.title()} x{qty}: ${item_total:.2f}\n"
    summary_text += f"\nTotal: ${total:.2f}"
    msgbox(summary_text)

    date = get_valid_date()#Asks for the users transaction date and saves to txt

    with open(transaction, "a") as file:#appending
        if file.tell() == 0:
        #if the txt file doesn't contain that header, it will write it
            file.write("Total,Date\n")
        file.write(f"{total:.2f},{date}\n")

    msgbox("Transaction saved to 'transactions.txt'.")


def plot_transaction_graph():
    try:
        df = pd.read_csv(transaction)
        if df.empty:#this checks if the transaction history is empty or not
            msgbox("No transaction data available to plot")
            return
            
        df_grouped = df.groupby("Date")["Total"].sum().reset_index()
        #colors of bar graphs
        colors = ["blue", "green", "orange", "red", "purple"] * (len(df_grouped) // 5 + 1)
        df_grouped.plot(x="Date", y="Total", kind="bar", color=colors[:len(df_grouped)])

        plt.title("Transaction Spending History")
        plt.xlabel("Date") #x axis marking the date of transaction
        plt.ylabel("Total ($)")# y axis of spending
        plt.tight_layout()
        plt.show()
            
    except FileNotFoundError:  #if the file does not exist the program wont crash
        msgbox("No transaction history found")

while True:#this is the loop of the program
    start = ynbox("Start shopping?")
    if not start:
        msgbox("Goodbye!")
        break

    show_cart()
    show_store_items()

    buy = ynbox("Do you want to buy something?")
    if not buy:
        msgbox("Thank you for visiting!")
        break
    if buy:
        add_to_cart()
        show_summary()
    else:
        msgbox("Thank you for visiting!")
        break

    restart = ynbox("Continue shopping?")
    if not restart:
        see_graph = ynbox("Do you want to see the transaction spending history graph?")
        if see_graph:
            plot_transaction_graph()
        msgbox("Thank you for shopping. Goodbye!")
        break
